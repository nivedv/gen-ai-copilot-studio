# Vendor Management and Procurement Policy

**Document Type:** Policy & Procedure  
**Document ID:** PROC-FIN-003  
**Version:** 2.1  
**Effective Date:** April 1, 2024  
**Last Reviewed:** August 15, 2024  
**Policy Owner:** Chief Procurement Officer  
**Approved By:** Finance Committee  

---

## 1. Executive Summary

### 1.1 Purpose
This policy establishes comprehensive guidelines for vendor selection, onboarding, management, and monitoring to ensure:
- Procurement activities align with organizational objectives and ethical standards
- Vendor relationships deliver optimal value while managing risk
- Compliance with regulatory requirements and internal controls
- Transparency and accountability in the procurement process

### 1.2 Scope
This policy applies to:
- All procurement of goods and services exceeding $5,000
- All employees authorized to engage vendors or commit company resources
- All business units, subsidiaries, and international operations
- Third-party vendors, contractors, consultants, and service providers

**Exclusions:** Employee reimbursements, utility services, emergency purchases under $10,000 (with post-approval required)

---

## 2. Vendor Selection and Onboarding

### 2.1 Vendor Selection Process

#### 2.1.1 Procurement Thresholds and Requirements

| Purchase Value | Requirements | Approvals Required |
|----------------|--------------|-------------------|
| $5,000 - $24,999 | Minimum 2 quotes | Department Manager |
| $25,000 - $99,999 | Minimum 3 quotes, comparison matrix | Department Head + Procurement |
| $100,000 - $499,999 | Formal RFP, evaluation committee | VP + CPO |
| $500,000+ | Formal RFP, board presentation | EVP + CFO + Board |

#### 2.1.2 Request for Proposal (RFP) Process

**When Required:**
- Purchases exceeding $100,000
- Multi-year contracts regardless of annual value
- Strategic vendor relationships (IT systems, professional services)
- Any procurement where competition enhances value

**RFP Timeline:**
1. **Week 1-2:** Develop RFP document, define requirements, form evaluation committee
2. **Week 3:** Publish RFP, vendor questions period opens
3. **Week 4:** Vendor questions due, responses published
4. **Week 5-6:** Proposals due, initial screening
5. **Week 7:** Vendor presentations and demonstrations
6. **Week 8:** Final evaluation, reference checks, selection
7. **Week 9-10:** Contract negotiation and execution

#### 2.1.3 Vendor Evaluation Criteria

All vendors evaluated using standardized scorecard:

| Criteria | Weight | Evaluation Factors |
|----------|--------|-------------------|
| **Price Competitiveness** | 30% | Total cost of ownership, payment terms, price stability |
| **Quality & Capability** | 25% | Technical expertise, quality certifications, past performance |
| **Financial Stability** | 20% | Credit rating, financial statements, business continuity |
| **Compliance & Risk** | 15% | Insurance, regulatory compliance, cybersecurity posture |
| **Service & Support** | 10% | Responsiveness, SLA commitments, escalation procedures |

**Minimum Threshold:** Vendors must score ≥70/100 to be eligible for selection.

### 2.2 Vendor Due Diligence

#### 2.2.1 Standard Due Diligence (All Vendors)

Required documentation:
- ✅ W-9 form (for US vendors) or W-8 (for international vendors)
- ✅ Certificate of Insurance (COI) with required coverage limits
- ✅ Completed Vendor Information Form
- ✅ Bank account verification for payment setup
- ✅ Conflict of Interest Disclosure (signed by vendor)

#### 2.2.2 Enhanced Due Diligence (Risk-Based)

**Triggers for Enhanced Due Diligence:**
- Annual spend >$250,000
- Access to sensitive data (customer, financial, employee)
- Critical infrastructure or business processes
- International vendors (FCPA compliance)
- First-time vendors without established track record

**Additional Requirements:**
- 📋 Financial statements (most recent 2 years)
- 📋 Dun & Bradstreet credit report
- 📋 Reference checks (minimum 3 clients)
- 📋 Site visit or virtual facility tour
- 📋 Background checks on key personnel
- 📋 Cybersecurity assessment questionnaire
- 📋 Business continuity and disaster recovery plan review

#### 2.2.3 Risk Assessment

Vendors categorized by risk level:

**Low Risk:**
- Standard goods/services, non-critical
- No access to systems or data
- Annual spend <$50,000
- **Review Frequency:** Annual

**Medium Risk:**
- Moderate business impact if relationship fails
- Limited system access (read-only)
- Annual spend $50,000-$250,000
- **Review Frequency:** Semi-annual

**High Risk:**
- Mission-critical services or sole-source vendor
- Access to sensitive data or production systems
- Annual spend >$250,000 or strategic importance
- **Review Frequency:** Quarterly

### 2.3 Vendor Onboarding Workflow

**Step 1: Vendor Registration**
- Vendor submits information via vendor portal or email to procurement@company.com
- Procurement team reviews submission for completeness
- Missing documents requested via automated workflow

**Step 2: Due Diligence Review**
- Risk rating assigned based on spend and criticality
- Appropriate due diligence package completed
- Legal reviews contract terms
- Information Security reviews data access (if applicable)

**Step 3: Approvals**
- Procurement Manager approves vendor setup (standard vendors)
- CPO approval required for high-risk vendors
- CFO approval required for vendors with annual spend >$1M

**Step 4: System Setup**
- Vendor created in SAP MM module
- Payment terms configured
- Tax information validated
- Vendor assigned to appropriate purchasing groups

**Timeline:** Standard onboarding completed within 10 business days of receiving complete documentation.

---

## 3. Contract Management

### 3.1 Contract Requirements

#### 3.1.1 Mandatory Contract Provisions

All vendor contracts must include:
- **Scope of Work:** Detailed description of deliverables and services
- **Pricing and Payment Terms:** Fixed price, rates, payment schedule, invoicing requirements
- **Term and Termination:** Contract duration, renewal terms, termination rights (with/without cause)
- **Performance Standards:** Service level agreements (SLAs), quality metrics, KPIs
- **Compliance Requirements:** Applicable laws, regulations, company policies
- **Indemnification:** Liability coverage and limits
- **Confidentiality:** Protection of proprietary information
- **Insurance Requirements:** Minimum coverage levels
- **Audit Rights:** Company's right to audit vendor performance and compliance
- **Dispute Resolution:** Escalation process, mediation, arbitration provisions

#### 3.1.2 Insurance Requirements

| Vendor Category | Required Coverage |
|----------------|------------------|
| **Professional Services** | Professional Liability: $2M, General Liability: $1M |
| **Construction/Manufacturing** | General Liability: $5M, Workers' Comp: Statutory limits |
| **IT Services/Software** | Cyber Liability: $5M, E&O: $2M, General Liability: $2M |
| **Transportation/Logistics** | Auto Liability: $5M, Cargo: $1M, General Liability: $2M |

**Certificate of Insurance (COI):**
- Company listed as "Certificate Holder" and "Additional Insured"
- 30-day cancellation notice required
- Annual COI renewal verification

### 3.2 Contract Approval Authority

| Contract Value | Signature Authority | Legal Review Required |
|----------------|--------------------|--------------------|
| Up to $50,000 | Procurement Manager | No (use standard template) |
| $50,001 - $250,000 | Director of Procurement | Yes (expedited review) |
| $250,001 - $1,000,000 | Chief Procurement Officer | Yes (full review) |
| Over $1,000,000 | CFO or CEO | Yes (full review + Board notification) |

**Exceptions:** IT system contracts, data processing agreements, and multi-year commitments require Legal review regardless of value.

### 3.3 Contract Repository and Lifecycle Management

**Contract Storage:**
- All executed contracts stored in SharePoint Contract Management Library
- Indexed by vendor name, contract type, expiration date, and owner
- Access restricted based on role (view vs. edit permissions)

**Contract Renewal Management:**
- Automated alerts 90 days before contract expiration
- Business owner reviews performance and determines renewal recommendation
- Procurement initiates renegotiation or competitive process
- Contracts not renewed by expiration automatically terminate (no auto-renewals)

**Amendment Process:**
- All contract changes require written amendment
- Material changes (>10% value increase, scope change) require same approval as original
- Non-material changes (administrative updates) approved by Procurement Manager

---

## 4. Procurement Process and Controls

### 4.1 Purchase Order Requirements

**When PO Required:**
- All purchases of goods and services ≥$5,000
- Recurring services (regardless of individual transaction size)
- Any vendor requiring formal authorization

**PO Creation in SAP:**
1. Requestor creates purchase requisition with:
   - Detailed description of goods/services
   - Quantity, unit price, total cost
   - Budget code and cost center
   - Business justification
   - Preferred vendor (if applicable)

2. Approval workflow (automated):
   - Budget holder approval (confirms funds available)
   - Department manager approval (validates business need)
   - Procurement approval (for purchases >$25,000)

3. Procurement team converts approved requisition to PO
4. PO transmitted to vendor via email or EDI

**PO Amendment:**
- Changes >5% of original PO value require re-approval
- Changes documented via PO change order in SAP

### 4.2 Three-Way Match Process

**Automated Control in SAP:**
For payment to be processed, system validates:
1. **Purchase Order** - Authorized PO exists
2. **Goods Receipt** - Receipt confirmation entered by receiving department
3. **Vendor Invoice** - Invoice matches PO and goods receipt

**Match Tolerance:**
- Price variance tolerance: ±5% or $100, whichever is less
- Quantity variance tolerance: ±2%
- Variances exceeding tolerance require manual approval by Procurement Manager

**Exception Handling:**
- Non-PO invoices (approved list only): VP approval required
- Services without formal receipt: Department manager confirms completion
- Disputed invoices: Hold payment, Procurement investigates, resolution within 15 days

### 4.3 Segregation of Duties

**Incompatible Duties - Controls:**
- ❌ Same person cannot create PO and approve invoice
- ❌ Same person cannot receive goods and process payment
- ❌ Vendor master data changes require dual approval
- ✅ Purchasing, receiving, and payment functions performed by separate individuals
- ✅ Quarterly SoD review by Internal Audit

---

## 5. Vendor Performance Management

### 5.1 Performance Monitoring

**Key Performance Indicators (KPIs):**

| Category | Metrics | Target |
|----------|---------|--------|
| **Delivery Performance** | On-time delivery rate | ≥95% |
| **Quality** | Defect rate, rejection rate | ≤2% |
| **Responsiveness** | Response time to inquiries | ≤24 hours |
| **Compliance** | Invoice accuracy rate | ≥98% |
| **Cost** | Budget variance | ±3% |

**Monitoring Frequency:**
- **Critical vendors:** Monthly scorecard
- **Strategic vendors:** Quarterly business review
- **Standard vendors:** Annual review

### 5.2 Vendor Scorecard

**Quarterly Vendor Scorecard Components:**

1. **Quantitative Metrics (70%):**
   - Delivery performance: 25%
   - Quality metrics: 25%
   - Cost performance: 20%

2. **Qualitative Assessment (30%):**
   - Communication and collaboration
   - Innovation and continuous improvement
   - Problem resolution effectiveness

**Scoring Scale:**
- 90-100: Excellent (Preferred Vendor status)
- 75-89: Good (Meets expectations)
- 60-74: Needs Improvement (Performance Improvement Plan required)
- <60: Unsatisfactory (Vendor termination consideration)

### 5.3 Vendor Business Reviews

**Quarterly Business Review (QBR) Agenda:**
- Performance scorecard review
- Service delivery metrics
- Escalation and issue log review
- Continuous improvement initiatives
- Upcoming projects and roadmap
- Risk and compliance updates

**Attendees:**
- Business owner (department head)
- Procurement relationship manager
- Vendor account manager
- Additional stakeholders as needed

**Documentation:**
- Meeting minutes with action items
- Updated scorecard
- Signed QBR summary document
- Stored in vendor file (SharePoint)

---

## 6. Vendor Risk and Compliance

### 6.1 Ongoing Risk Assessment

**Annual Vendor Risk Review:**
Procurement team conducts comprehensive annual review of all active vendors:

✅ **Financial Health Check:**
- Review updated financial statements
- Monitor D&B credit rating changes
- Track news for bankruptcy, merger, acquisition
- Assess business continuity risks

✅ **Compliance Verification:**
- Confirm valid insurance coverage
- Verify regulatory licenses and certifications
- Review audit reports (SOC 2, ISO certifications)
- Validate background check currency (if applicable)

✅ **Cybersecurity Assessment:**
- Review security questionnaire responses
- Validate data handling practices
- Confirm breach notification procedures
- Assess third-party security audits

**Red Flags Requiring Immediate Action:**
- 🚨 Credit rating downgrade below investment grade
- 🚨 Insurance coverage lapsed or inadequate
- 🚨 Data breach or security incident
- 🚨 Regulatory violation or legal action
- 🚨 Change in ownership or key personnel
- 🚨 Repeated performance failures

### 6.2 Vendor Master Data Management

**Data Integrity Controls:**
- Vendor creation requires Procurement approval
- Duplicate vendor check performed before setup
- Bank account changes require vendor confirmation (phone verification)
- Vendor master data changes logged and reviewed monthly
- Inactive vendors (no transactions in 24 months) archived quarterly

**Fraud Prevention:**
- Suspected fraudulent vendor communication reported to Legal and Finance immediately
- Payment routing changes verified through known contact (not email request)
- New vendor payment holds for 30 days (fraud monitoring period)

---

## 7. Vendor Termination and Offboarding

### 7.1 Termination Reasons

**For Cause:**
- Material breach of contract
- Repeated performance failures (scorecard <60 for 2+ quarters)
- Fraudulent activity or ethical violations
- Bankruptcy or inability to perform
- Non-compliance with legal/regulatory requirements

**Without Cause:**
- Strategic business decision (in-sourcing, vendor consolidation)
- Contract expiration with no renewal
- Budget constraints
- Service no longer required

### 7.2 Termination Process

**Step 1: Termination Notice**
- Legal reviews termination provisions in contract
- Notice period per contract (typically 30-90 days)
- Written termination letter sent via certified mail and email
- Business owner notified of termination timeline

**Step 2: Transition Planning**
- Identify replacement vendor or transition to internal resources
- Document knowledge transfer requirements
- Schedule data extraction and return
- Coordinate return of company property

**Step 3: Final Deliverables and Payment**
- Confirm completion or partial completion of work
- Process final invoices (within 30 days)
- Conduct final performance review
- Archive all vendor records

**Step 4: System Deactivation**
- Revoke system access (within 24 hours of termination effective date)
- Mark vendor as "Inactive" in SAP (do not delete - audit trail)
- Remove from approved vendor list
- Update contract management system

### 7.3 Post-Termination

**Lessons Learned:**
- Document reasons for termination
- Identify process improvements
- Update vendor selection criteria if applicable
- Share insights with procurement team

**Record Retention:**
- Contracts and amendments: 7 years
- Performance scorecards: 5 years
- Invoices and payment records: 7 years (per IRS requirements)
- Correspondence: 3 years

---

## 8. Roles and Responsibilities

| Role | Key Responsibilities |
|------|---------------------|
| **Chief Procurement Officer** | Policy ownership, vendor strategy, high-value contract approval |
| **Procurement Team** | Vendor onboarding, contracting, relationship management, compliance monitoring |
| **Legal** | Contract review, risk assessment, dispute resolution |
| **Finance** | Payment processing, vendor master data, financial risk assessment |
| **Information Security** | Cybersecurity risk assessment, data protection compliance |
| **Business Owners** | Requirements definition, vendor performance monitoring, budget accountability |
| **Internal Audit** | Control testing, compliance audits, SOD reviews |

---

## 9. Related Documents and Resources

- **Vendor Information Form** (FORM-PROC-001)
- **Vendor Risk Assessment Questionnaire** (FORM-PROC-002)
- **Standard Master Services Agreement Template** (TEMP-LEGAL-MSA)
- **Vendor Scorecard Template** (TEMP-PROC-003)
- **Purchase Requisition Guidelines** (GUIDE-PROC-001)
- **Conflict of Interest Policy** (POL-CORP-005)

**Vendor Portal:** [https://vendor.company.com](https://vendor.company.com)  
**Procurement Contact:** procurement@company.com

---

## 10. Policy Review and Updates

**Review Frequency:** Annual (or as needed for regulatory changes)  
**Next Scheduled Review:** April 2025  
**Policy Owner:** Chief Procurement Officer  

**Revision History:**

| Version | Date | Changes | Approved By |
|---------|------|---------|-------------|
| 1.0 | Jan 15, 2022 | Initial policy release | Finance Committee |
| 1.5 | Sep 10, 2022 | Added cybersecurity requirements | Finance Committee |
| 2.0 | Apr 01, 2023 | Enhanced due diligence process | Finance Committee |
| 2.1 | Apr 01, 2024 | Updated approval thresholds, added QBR requirements | Finance Committee |

---

**Document Classification:** Internal Use  
**Questions?** Contact Procurement Team at procurement@company.com
