# Data Privacy and GDPR Compliance Policy

**Document Type:** Policy  
**Document ID:** POL-SEC-GDPR-001  
**Version:** 4.0  
**Effective Date:** May 25, 2024  
**Last Reviewed:** October 1, 2024  
**Policy Owner:** Data Protection Officer  
**Approved By:** Executive Committee & Board of Directors  

---

## 1. Policy Statement and Scope

### 1.1 Purpose
This policy establishes the framework for protecting personal data and ensuring compliance with the General Data Protection Regulation (GDPR) and other applicable privacy laws. The organization is committed to:
- Protecting the privacy rights of individuals (data subjects)
- Processing personal data lawfully, fairly, and transparently
- Implementing appropriate technical and organizational measures to safeguard data
- Demonstrating accountability and compliance with privacy regulations

### 1.2 Scope
This policy applies to:
- **Data:** All personal data processed by the organization, regardless of format (electronic, paper, verbal)
- **Geography:** EEA/UK personal data and any data processed in our European operations
- **People:** All employees, contractors, vendors, and third parties processing personal data on our behalf
- **Systems:** All IT systems, applications, databases, and filing systems containing personal data

### 1.3 Regulatory Framework
Compliance obligations include:
- EU General Data Protection Regulation (GDPR) - Regulation (EU) 2016/679
- UK GDPR and Data Protection Act 2018
- California Consumer Privacy Act (CCPA) - for California residents
- Other applicable regional privacy laws

---

## 2. Key Definitions

### 2.1 Personal Data
Any information relating to an identified or identifiable natural person ("data subject"), including:

**Directly Identifying:**
- Name, email address, phone number
- Employee ID, customer ID, account number
- IP address, device identifiers, cookie IDs
- Physical address, GPS coordinates
- Photographs, voice recordings, video

**Indirectly Identifying (when combined):**
- Job title + company + location
- Age + postal code + gender
- Purchase history + browsing behavior

### 2.2 Special Categories of Personal Data (Sensitive Data)
Data requiring enhanced protection:
- Racial or ethnic origin
- Political opinions, religious or philosophical beliefs
- Trade union membership
- Genetic data, biometric data (when used for identification)
- Health data, medical records
- Sex life or sexual orientation
- Criminal convictions and offences

**Note:** Processing special categories requires explicit consent or other lawful basis under GDPR Article 9.

### 2.3 Data Roles

| Role | Definition | Responsibilities |
|------|------------|------------------|
| **Data Subject** | Individual whose personal data is processed | Exercise privacy rights (access, erasure, etc.) |
| **Data Controller** | Organization determining purposes and means of processing | Ensure lawful processing, respond to rights requests |
| **Data Processor** | Organization processing data on behalf of controller | Process only on documented instructions, maintain security |
| **Data Protection Officer (DPO)** | Independent advisor on data protection | Monitor compliance, advise on DPIAs, liaise with authorities |

---

## 3. Data Protection Principles

All personal data processing must adhere to GDPR's six core principles:

### 3.1 Lawfulness, Fairness, and Transparency
**Requirement:** Process data lawfully, fairly, and in a transparent manner.

**Implementation:**
- ✅ Identify valid legal basis before processing (see Section 4)
- ✅ Provide clear privacy notices at point of collection
- ✅ Do not process data in ways individuals wouldn't reasonably expect
- ✅ Maintain records of processing activities (ROPA)

### 3.2 Purpose Limitation
**Requirement:** Collect data for specified, explicit, legitimate purposes only.

**Implementation:**
- ✅ Define specific purposes before data collection
- ✅ Document purposes in privacy notices and ROPA
- ✅ Restrict use to stated purposes (no "mission creep")
- ✅ Conduct compatibility assessment before repurposing data

### 3.3 Data Minimization
**Requirement:** Process only data that is adequate, relevant, and limited to what is necessary.

**Implementation:**
- ✅ Collect only essential data fields for stated purpose
- ✅ Review forms and databases to eliminate unnecessary fields
- ✅ Avoid "just in case" data collection
- ✅ Regularly review and delete redundant data

### 3.4 Accuracy
**Requirement:** Keep personal data accurate and up to date.

**Implementation:**
- ✅ Implement data validation at point of entry
- ✅ Provide mechanisms for individuals to update their information
- ✅ Conduct periodic data quality reviews
- ✅ Correct or delete inaccurate data promptly

### 3.5 Storage Limitation
**Requirement:** Retain data only as long as necessary for the stated purpose.

**Implementation:**
- ✅ Define retention periods for each data category (see Section 8)
- ✅ Implement automated deletion/archival workflows
- ✅ Review and purge data at end of retention period
- ✅ Document legal or regulatory retention requirements

### 3.6 Integrity and Confidentiality (Security)
**Requirement:** Process data securely with appropriate technical and organizational measures.

**Implementation:**
- ✅ Encryption for data at rest and in transit
- ✅ Access controls (role-based, least privilege)
- ✅ Regular security testing and vulnerability assessments
- ✅ Incident response and breach notification procedures

### 3.7 Accountability
**Requirement:** Demonstrate compliance with all principles.

**Implementation:**
- ✅ Maintain comprehensive documentation (policies, DPIAs, ROPA)
- ✅ Implement privacy by design and default
- ✅ Conduct regular compliance audits
- ✅ Train employees on privacy obligations

---

## 4. Legal Basis for Processing

### 4.1 Lawful Bases Under GDPR Article 6

All processing must be based on at least one of the following:

**1. Consent**
- **Definition:** Freely given, specific, informed, and unambiguous indication of agreement
- **Requirements:** 
  - Must be explicit opt-in (pre-ticked boxes invalid)
  - Separate consent for different purposes
  - Easy to withdraw (as easy as to give)
  - Documented with timestamp and consent text
- **Use Cases:** Marketing communications, optional data sharing, cookies (non-essential)

**2. Contract**
- **Definition:** Processing necessary to perform a contract with the data subject
- **Examples:** 
  - Customer order fulfillment and delivery
  - Payment processing
  - Account management and customer support
  - Employment contracts (payroll, benefits)

**3. Legal Obligation**
- **Definition:** Processing required to comply with a legal obligation
- **Examples:**
  - Tax reporting and accounting records
  - Employment law compliance (wage and hour records)
  - Health and safety regulations
  - Anti-money laundering (AML) checks

**4. Vital Interests**
- **Definition:** Processing necessary to protect someone's life
- **Examples:** Medical emergencies, disaster response
- **Note:** Rarely applicable in commercial contexts

**5. Public Task**
- **Definition:** Processing necessary for public interest or official authority
- **Applicability:** Primarily government and public sector

**6. Legitimate Interests**
- **Definition:** Processing necessary for legitimate interests of controller or third party (unless overridden by data subject's interests)
- **Requirements:** Conduct Legitimate Interests Assessment (LIA)
- **Examples:**
  - Fraud prevention and network security
  - Internal administrative purposes
  - Direct marketing to existing customers (B2B)
  - Sharing data with parent/subsidiary companies
- **Prohibited Uses:** Cannot be used for special category data or children's data

### 4.2 Legal Basis Assessment

**Before processing personal data, complete Legal Basis Assessment:**
1. Identify purpose of processing
2. Select most appropriate lawful basis
3. Document rationale and assessment
4. Update privacy notice to reflect legal basis
5. Store assessment in data protection records

---

## 5. Individual Rights (Data Subject Rights)

### 5.1 Right of Access (Subject Access Request - SAR)

**Right:** Individuals can request copy of their personal data and information about how it's processed.

**Process:**
1. Request received via email (privacy@company.com) or Privacy Portal
2. DPO team verifies identity (government ID or two-factor authentication)
3. Search all systems and databases for requester's data
4. Compile data package with processing information
5. Deliver response within **1 month** (extendable by 2 months if complex)

**Response Includes:**
- Copy of personal data held
- Purposes of processing
- Categories of data
- Recipients or categories of recipients
- Retention period
- Source of data (if not collected from individual)
- Information about automated decision-making

**Fee:** Free for first request; reasonable fee for excessive/repetitive requests

### 5.2 Right to Rectification

**Right:** Individuals can request correction of inaccurate or incomplete personal data.

**Process:**
1. Request received with corrected information
2. Verify accuracy of correction (may request supporting documentation)
3. Update data in all systems within **1 month**
4. Notify third parties who received the data (if applicable)
5. Confirm completion to requester

### 5.3 Right to Erasure ("Right to be Forgotten")

**Right:** Individuals can request deletion of their personal data in specific circumstances.

**Valid Grounds for Erasure:**
- Data no longer necessary for original purpose
- Consent withdrawn (and no other legal basis exists)
- Objection to processing (and no overriding legitimate grounds)
- Data processed unlawfully
- Legal obligation to erase
- Data collected from children for online services

**Exceptions (Erasure May Be Refused):**
- Legal obligation to retain (tax records, employment law)
- Legal claims or defense
- Public health reasons
- Archiving/research purposes with appropriate safeguards

**Process:**
1. Evaluate grounds for erasure and exceptions
2. If approved: Delete data from all systems (including backups within backup cycle)
3. Notify third parties who received the data
4. Respond within **1 month**

### 5.4 Right to Restriction of Processing

**Right:** Request temporary suspension of processing in specific situations.

**Triggers:**
- Accuracy of data is contested (restrict while verifying)
- Processing is unlawful but individual prefers restriction over erasure
- Data no longer needed but individual needs it for legal claims
- Objection to processing pending verification of legitimate grounds

**Implementation:** Mark data as "restricted" - retain but not process (except storage, legal claims, or with consent)

### 5.5 Right to Data Portability

**Right:** Receive personal data in structured, commonly used, machine-readable format and transmit to another controller.

**Conditions:**
- Processing based on consent or contract
- Processing carried out by automated means
- Technically feasible

**Deliverables:**
- Data in CSV, JSON, or XML format
- Transmitted directly to new controller if requested (if technically feasible)

### 5.6 Right to Object

**Right:** Object to processing based on legitimate interests or for direct marketing.

**Direct Marketing:**
- Absolute right - must cease immediately upon objection
- Opt-out link in every marketing email
- Preference center for granular control

**Legitimate Interests Processing:**
- Organization may continue if compelling legitimate grounds override individual's interests
- Conduct balancing test and document decision

### 5.7 Rights Request Handling - SLA

| Request Type | Response Deadline | Complexity Extension |
|--------------|------------------|---------------------|
| Access (SAR) | 1 month | +2 months (notify within 1 month) |
| Rectification | 1 month | +2 months (notify within 1 month) |
| Erasure | 1 month | +2 months (notify within 1 month) |
| Restriction | 1 month | +2 months (notify within 1 month) |
| Portability | 1 month | +2 months (notify within 1 month) |
| Object (Marketing) | Immediately | Not applicable |

---

## 6. Data Protection Impact Assessments (DPIA)

### 6.1 When DPIA Required

**Mandatory Triggers:**
- Systematic and extensive profiling with significant effects
- Large-scale processing of special category data
- Systematic monitoring of publicly accessible areas (CCTV)
- Use of new technologies with high privacy risk
- Automated decision-making with legal or similar significant effects
- Processing children's data at scale
- Processing involving cross-border data transfers outside EEA

**DPIA Threshold Assessment:**
Complete screening questionnaire for all new projects/systems involving personal data.

### 6.2 DPIA Process

**Step 1: Describe Processing**
- Nature, scope, context, and purposes of processing
- Types of personal data and data subjects
- Data flows and system architecture

**Step 2: Assess Necessity and Proportionality**
- Is processing necessary for stated purpose?
- Are less intrusive alternatives available?
- Is data minimization applied?

**Step 3: Identify and Assess Risks**
Evaluate risks to individuals' rights and freedoms:
- Unauthorized access or disclosure
- Accidental loss or destruction
- Discrimination or identity theft
- Reputational damage
- Loss of confidentiality

**Risk Rating:** Likelihood × Impact = Risk Score (Low/Medium/High)

**Step 4: Identify Mitigation Measures**
- Technical controls (encryption, anonymization, access controls)
- Organizational measures (policies, training, contracts)
- Residual risk assessment

**Step 5: Review and Approval**
- DPO review and sign-off
- Consult supervisory authority if high residual risk remains

**Step 6: Monitor and Review**
- Reassess if significant changes to processing
- Annual review for high-risk processing

**DPIA Template:** Available on Privacy SharePoint site (FORM-GDPR-DPIA)

---

## 7. International Data Transfers

### 7.1 Transfer Mechanisms

**Transfers Outside EEA/UK Require Safeguards:**

**Option 1: Adequacy Decision**
- EU Commission recognized country provides adequate protection
- Current adequate countries: UK, Switzerland, Canada, Japan, South Korea, Israel, New Zealand, Argentina, Uruguay, Andorra, Faroe Islands, Guernsey, Jersey, Isle of Man

**Option 2: Standard Contractual Clauses (SCCs)**
- EU-approved model contracts between data exporter and importer
- Must conduct Transfer Impact Assessment (TIA)
- Implementation: Execute SCC addendum with vendor/subsidiary

**Option 3: Binding Corporate Rules (BCRs)**
- Approved internal data protection policies for multinational groups
- Implementation: Our BCRs approved by Irish DPA (lead authority)

**Option 4: Derogations (Limited Use)**
- Explicit consent for specific transfer
- Necessary for contract performance
- Important public interest reasons
- **Note:** Not viable for routine/repetitive transfers

### 7.2 US Data Transfers (Post-Schrems II)

**EU-US Data Privacy Framework (DPF):**
- US companies self-certify to DPF (successor to Privacy Shield)
- Verify vendor certification: https://www.dataprivacyframework.gov/list
- Annual re-certification required

**Transfer Impact Assessment (TIA):**
For transfers to non-adequate countries:
1. Assess laws of destination country (government access, surveillance)
2. Evaluate supplementary measures needed beyond SCCs
3. Document assessment and decision
4. Re-assess if circumstances change

---

## 8. Data Retention and Disposal

### 8.1 Retention Schedules

| Data Category | Retention Period | Legal Basis | Disposal Method |
|--------------|-----------------|-------------|-----------------|
| **Customer Data** | | | |
| Active customer records | Duration of relationship + 3 years | Contract, Legal | Secure deletion |
| Transactional data | 7 years | Legal (tax) | Secure deletion |
| Marketing consent records | Consent valid + 3 years | Accountability | Secure deletion |
| **Employee Data** | | | |
| Personnel files | Termination + 7 years | Legal (employment law) | Secure destruction |
| Payroll records | 7 years | Legal (tax) | Secure destruction |
| Recruitment (unsuccessful) | 6 months | Legitimate interests | Secure deletion |
| **Compliance Records** | | | |
| GDPR documentation (DPIAs, ROPA) | Life of processing + 3 years | Accountability | Archive |
| Privacy notices | Superseded + 3 years | Accountability | Archive |
| Data breach records | Incident date + 5 years | Accountability | Archive |

### 8.2 Data Disposal Procedures

**Electronic Data:**
- Cryptographic erasure (encryption key destruction)
- Secure deletion software (DOD 5220.22-M standard)
- Physical destruction of storage media (degaussing, shredding)

**Paper Records:**
- Cross-cut shredding (P-4 standard or higher)
- Certified destruction service for bulk disposal
- Certificate of destruction retained

**Backup Data:**
- Data purged from backups within normal backup rotation cycle (90 days)
- Document retention obligations that exceed backup cycle

---

## 9. Data Security Measures

### 9.1 Technical Controls

**Encryption:**
- At rest: AES-256 for databases and file storage
- In transit: TLS 1.2+ for all data transmissions
- Email: S/MIME or PGP for sensitive data

**Access Controls:**
- Role-based access control (RBAC)
- Multi-factor authentication for remote access and privileged accounts
- Quarterly access reviews
- Immediate revocation upon termination

**Network Security:**
- Firewalls and intrusion detection systems
- Network segmentation (separate production, development, DMZ)
- Regular vulnerability scanning and penetration testing

**Application Security:**
- Secure development lifecycle (SDL)
- Code reviews and static analysis
- Web application firewall (WAF)
- Security patching within 30 days of release

### 9.2 Organizational Measures

**Privacy by Design and Default:**
- Privacy considerations integrated from project inception
- Default settings provide maximum privacy protection
- Data minimization and pseudonymization where possible

**Training and Awareness:**
- Annual privacy training for all employees (completion mandatory)
- Specialized training for roles handling sensitive data
- Phishing simulations and security awareness campaigns

**Incident Response:**
- 24/7 security monitoring (SOC)
- Defined incident response plan
- Data breach notification procedures (see Section 10)

**Vendor Management:**
- Data Processing Agreements (DPAs) with all processors
- Annual security questionnaires
- Right to audit vendor controls

---

## 10. Data Breach Management

### 10.1 Breach Notification Timeline

**Internal Notification:**
- Discovery → Report to Information Security: **Immediately**
- Information Security → DPO: **Within 2 hours**
- DPO → Executive Team: **Within 4 hours** (if likely breach)

**Regulatory Notification:**
- DPO → Supervisory Authority: **Within 72 hours** of becoming aware (if risk to individuals)
- Notification Method: Via supervisory authority online portal

**Individual Notification:**
- DPO → Affected Individuals: **Without undue delay** (if high risk to rights and freedoms)
- Notification Method: Email (or letter if email unavailable)

### 10.2 Breach Assessment Criteria

**Risk to Individuals - Factors to Consider:**
- Type and sensitivity of data (special category = higher risk)
- Volume of affected individuals
- Ease of identifying individuals from breached data
- Severity of consequences (financial loss, identity theft, discrimination)
- Special characteristics of individuals (children, vulnerable groups)
- Ability of individuals to mitigate harm

**Example Risk Scenarios:**

| Breach Scenario | Notification Required? |
|-----------------|----------------------|
| Encrypted laptop stolen (strong encryption) | No - low risk |
| Unencrypted USB with 10,000 customer emails lost | Yes - regulators and individuals |
| Health records accessed by unauthorized employee | Yes - high risk (special category data) |
| Marketing email sent to wrong recipient (BCC error) | Assess impact - possibly yes |

### 10.3 Breach Documentation

**Breach Register - Required Information:**
- Date and time of breach discovery
- Nature of breach (accidental loss, unauthorized access, ransomware, etc.)
- Categories and approximate number of individuals affected
- Categories and approximate volume of records affected
- Consequences of breach (actual and potential)
- Remedial actions taken
- Notification decisions and rationale
- Lessons learned and preventive measures

---

## 11. Roles and Responsibilities

| Role | Key Responsibilities |
|------|---------------------|
| **Data Protection Officer (DPO)** | Monitor compliance, advise on obligations, conduct DPIAs, liaise with supervisory authorities |
| **Executive Team** | Accountability for compliance, resource allocation, data protection culture |
| **IT Security** | Implement technical controls, security monitoring, incident response |
| **Legal** | Contract review (DPAs), regulatory interpretation, breach legal assessment |
| **HR** | Employee data processing, training coordination, policy communication |
| **All Employees** | Comply with policy, protect personal data, report incidents, complete training |

---

## 12. Governance and Compliance

**Privacy Steering Committee:**
- **Chair:** Data Protection Officer
- **Members:** Legal, IT Security, HR, Compliance, Business Representatives
- **Meeting Frequency:** Quarterly
- **Agenda:** Compliance updates, DPIA reviews, incident analysis, policy updates

**Audit and Monitoring:**
- Internal Audit: Annual privacy controls testing
- DPO: Quarterly compliance self-assessments
- Third-Party Audit: Biennial external privacy audit

**Record of Processing Activities (ROPA):**
- Maintained by DPO in centralized register
- Updated within 30 days of processing changes
- Available for supervisory authority upon request

---

**Document Owner:** Data Protection Officer  
**Contact:** privacy@company.com | DPO Hotline: +44 (0) 20 1234 5678  
**Next Review Date:** May 2025

**Revision History:**

| Version | Date | Key Changes |
|---------|------|-------------|
| 1.0 | May 25, 2018 | Initial GDPR compliance policy |
| 2.0 | Jan 15, 2020 | Added CCPA provisions, updated SCCs |
| 3.0 | Oct 10, 2021 | Post-Schrems II transfer mechanisms |
| 4.0 | May 25, 2024 | Updated for new EU SCCs, DPF framework |

---

**Document Classification:** Internal - Compliance Required
