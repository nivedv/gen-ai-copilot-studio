# Access Control and User Management Policy

**Document Type:** Policy  
**Document ID:** POL-IT-001  
**Version:** 3.2  
**Effective Date:** January 15, 2024  
**Last Reviewed:** October 1, 2024  
**Owner:** Chief Information Security Officer  
**Approved By:** IT Steering Committee  

---

## 1. Purpose and Scope

### 1.1 Purpose
This policy establishes the standards and procedures for managing user access to information systems and applications across the organization. The policy ensures that access rights are granted based on business need and the principle of least privilege, protecting organizational assets from unauthorized access, modification, or disclosure.

### 1.2 Scope
This policy applies to:
- All employees, contractors, vendors, and third-party users
- All information systems, applications, and databases
- All access methods including remote access, privileged access, and application access
- Cloud-based and on-premises systems

---

## 2. Access Control Principles

### 2.1 Least Privilege
Users shall be granted the minimum level of access necessary to perform their job functions. Access rights must be:
- Role-based and aligned with job responsibilities
- Reviewed and approved by the user's manager and system owner
- Time-limited for temporary or project-based access
- Revoked immediately upon job role change or termination

### 2.2 Segregation of Duties (SoD)
Critical business processes must incorporate segregation of duties to prevent fraud and errors. Key incompatible duties include:
- Authorization and execution of transactions
- Custody of assets and record-keeping
- System administration and security monitoring
- Development and production environment access

### 2.3 Need-to-Know Basis
Access to sensitive or confidential information shall be restricted to individuals with a legitimate business need.

---

## 3. User Access Lifecycle Management

### 3.1 Access Provisioning (Joiner Process)

#### 3.1.1 New Hire Access Request
The hiring manager must submit an access request through the ServiceNow portal containing:
- Employee name and employee ID
- Job title and department
- Start date
- Required systems and access levels
- Business justification

#### 3.1.2 Approval Workflow
All access requests require dual approval:
1. **Manager Approval** - Hiring manager confirms business need
2. **System Owner Approval** - Application/system owner validates appropriateness

#### 3.1.3 Provisioning Timeline
- Standard access: Provisioned within 24 hours of approval
- Privileged access: Provisioned within 48 hours with additional security validation
- Emergency access: Provisioned within 4 hours with CISO approval

### 3.2 Access Modification (Mover Process)

When an employee changes roles:
- Manager initiates access modification request
- New access is provisioned before old access is revoked
- Transition period not to exceed 5 business days
- All changes documented in the access change log

### 3.3 Access Revocation (Leaver Process)

#### 3.3.1 Termination - Involuntary
- IT Security notified immediately by HR
- All access disabled within 1 hour of notification
- Physical access cards deactivated simultaneously
- Email forwarding configured for 30 days (manager access only)

#### 3.3.2 Termination - Voluntary
- IT Security notified 2 weeks before last day
- Access disabled on last working day at 5:00 PM
- Email forwarding configured for 60 days
- File transfer to manager completed before access removal

#### 3.3.3 Extended Leave
For leaves exceeding 30 days:
- Account disabled (not deleted)
- Manager notified of disabled status
- Account reactivated upon return with manager approval

---

## 4. System-Specific Access Requirements

### 4.1 SAP ERP Access

**Access Levels:**
- **Read-Only:** View-only access to modules
- **Standard User:** Execute transactions within assigned role
- **Power User:** Advanced functions including configuration
- **Administrator:** Full system access including user management

**Key Controls:**
- Segregation of duties matrix enforced through SAP GRC
- Quarterly access reviews by module owners
- Emergency access (firefighter IDs) logged and reviewed monthly
- No shared user IDs permitted

**Approval Requirements:**
| Access Level | Approvers Required |
|--------------|-------------------|
| Read-Only | Manager only |
| Standard User | Manager + Module Owner |
| Power User | Manager + Module Owner + IT Security |
| Administrator | Manager + CIO + CISO |

### 4.2 Active Directory and Network Access

**Account Naming Convention:**
- Standard format: firstname.lastname
- Service accounts: svc_applicationname
- Administrator accounts: firstname.lastname_admin

**Password Requirements:**
- Minimum 12 characters
- Complexity: uppercase, lowercase, numbers, special characters
- Password expiry: 90 days
- Password history: Cannot reuse last 10 passwords
- Account lockout: 5 failed attempts, 30-minute lockout period

**Multi-Factor Authentication (MFA):**
Required for:
- All remote access (VPN)
- All privileged accounts
- Access to financial systems
- Access to customer data
- Cloud application access (Office 365, Salesforce)

### 4.3 Database Access

**Production Database Access:**
- No direct production access for developers
- Read-only access granted only with business justification
- All queries logged and reviewed
- Write access requires change management approval

**Access Method:**
- Standard users: Application interface only
- DBAs: Direct database access with session recording
- Auditors: Read-only query access with 30-day expiration

---

## 5. Privileged Access Management

### 5.1 Definition of Privileged Access
Privileged access includes:
- System administrator accounts
- Database administrator accounts
- Application administrator accounts
- Service accounts with elevated permissions
- Accounts with ability to modify security settings

### 5.2 Privileged Account Controls

**Separate Accounts Required:**
- Users requiring privileged access must have two accounts:
  - Standard account for day-to-day work
  - Privileged account (username_admin) for administrative tasks

**Just-in-Time Access:**
- Privileged access granted on-demand for specific tasks
- Access automatically expires after 8 hours
- All privileged sessions recorded and retained for 1 year

**Additional Requirements:**
- Annual background checks for privileged users
- Mandatory security awareness training (quarterly)
- Signed privileged access agreement
- Manager and CISO approval required

---

## 6. Access Review and Certification

### 6.1 Quarterly Access Reviews

**System Owners Responsibilities:**
- Review all user access for assigned systems
- Certify appropriateness of access levels
- Document and remediate exceptions within 15 days
- Submit certification report to IT Security

**Review Process:**
1. IT Security generates access reports from each system
2. Reports distributed to system owners and managers
3. Reviewers certify or request removal within 30 days
4. IT Security tracks completion and follows up on overdue reviews
5. Executive summary presented to IT Steering Committee

### 6.2 High-Risk Access - Monthly Reviews
The following access types require monthly review:
- Administrator and privileged accounts
- Access to financial systems (SAP FI/CO modules)
- Customer data access (CRM, customer databases)
- Terminated employee accounts (verification of removal)

---

## 7. Remote and Third-Party Access

### 7.1 Remote Access Requirements
- VPN required for all remote connections
- MFA mandatory for VPN authentication
- Endpoint security validation (antivirus, patches, encryption)
- Split tunneling prohibited for corporate resources

### 7.2 Vendor and Contractor Access

**Access Request Process:**
- Sponsor (internal employee) must submit request
- Vendor personnel subject to background check
- Access limited to specific systems and timeframe
- Non-disclosure agreement (NDA) required
- Access automatically expires after 90 days (renewable)

**Monitoring:**
- All vendor activity logged
- Weekly review of vendor access by system owners
- Immediate termination upon contract completion

---

## 8. Monitoring and Compliance

### 8.1 Access Logging
All systems must log:
- Successful and failed login attempts
- Privileged account usage
- Access to sensitive data
- Account creation, modification, and deletion
- Permission changes

**Log Retention:**
- Standard logs: 90 days online, 1 year archived
- Financial system logs: 7 years
- Privileged access logs: 3 years

### 8.2 Access Violations
Violations of this policy may result in:
- Immediate access suspension
- Disciplinary action up to and including termination
- Legal action for willful misconduct
- Reporting to law enforcement for criminal activity

---

## 9. Roles and Responsibilities

| Role | Responsibilities |
|------|------------------|
| **CISO** | Policy ownership, oversight, and enforcement |
| **IT Security** | Access administration, monitoring, audit support |
| **System Owners** | Access approvals, quarterly reviews, compliance |
| **Managers** | Request appropriate access, review team access, immediate notification of terminations |
| **Users** | Protect credentials, report suspicious activity, comply with policy |
| **Internal Audit** | Independent testing of access controls, compliance validation |

---

## 10. Related Documents

- **POL-IT-002:** Password Management Policy
- **POL-IT-005:** Privileged Access Management Standard
- **PROC-IT-010:** User Provisioning Procedure
- **PROC-IT-011:** Access Review Procedure
- **FORM-IT-001:** Access Request Form
- **MATRIX-SAP-001:** SAP Segregation of Duties Matrix

---

## 11. Revision History

| Version | Date | Description | Approved By |
|---------|------|-------------|-------------|
| 1.0 | Jan 10, 2022 | Initial policy release | IT Steering Committee |
| 2.0 | Jul 15, 2022 | Added MFA requirements | IT Steering Committee |
| 2.5 | Jan 20, 2023 | Enhanced privileged access controls | IT Steering Committee |
| 3.0 | Jun 30, 2023 | Added third-party access section | IT Steering Committee |
| 3.1 | Mar 15, 2024 | Updated password complexity | IT Steering Committee |
| 3.2 | Oct 01, 2024 | Added just-in-time access | IT Steering Committee |

---

**Document Classification:** Internal Use Only  
**Next Review Date:** April 1, 2025
