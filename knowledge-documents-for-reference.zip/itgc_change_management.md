# IT General Controls - Change Management

**Document Type:** IT Control Standard  
**Document ID:** ITGC-CHG-001  
**Control Domain:** IT General Controls (ITGC)  
**Sub-Domain:** Change Management  
**Version:** 3.5  
**Effective Date:** March 1, 2024  
**Last Reviewed:** September 15, 2024  
**Control Owner:** IT Operations Manager  
**Approved By:** Chief Information Officer  

---

## 1. Executive Summary

### 1.1 Purpose
This document establishes standards and procedures for managing changes to IT systems, applications, infrastructure, and databases to ensure:
- Changes are authorized, tested, and documented before implementation
- Production stability and availability are maintained
- Segregation of duties between development and production is enforced
- Audit trails exist for all system modifications
- Compliance with SOX 404, ISO 27001, and other regulatory requirements

### 1.2 Scope
This standard applies to:

**In-Scope Systems:**
- Production systems supporting financial reporting (SAP ERP, Oracle Financials)
- Customer-facing applications (e-commerce platform, CRM)
- Critical infrastructure (Active Directory, email, network devices)
- Databases containing sensitive or business-critical data
- Cloud platforms and SaaS applications with configuration control

**In-Scope Changes:**
- Application code changes (new features, bug fixes, patches)
- Database schema modifications (tables, stored procedures, views)
- Infrastructure changes (server configurations, network rules, storage)
- Security configurations (firewall rules, access controls, encryption settings)
- Vendor-provided patches and updates

**Out-of-Scope (Exempt from Standard Change Process):**
- Pre-approved standard changes (see Section 5)
- Emergency changes following expedited process (see Section 6)
- Non-production environment changes (development, test, QA)

---

## 2. Change Management Framework

### 2.1 Change Categories

| Category | Definition | Approval Level | Examples |
|----------|-----------|----------------|----------|
| **Standard** | Pre-approved, low-risk, routine | Auto-approved (catalog) | Password resets, software installations from approved list, monthly patches |
| **Normal** | Planned change requiring evaluation | CAB approval | Application deployments, infrastructure upgrades, configuration changes |
| **Major** | High-risk, high-impact change | CAB + CIO approval | ERP upgrades, data center migrations, major platform changes |
| **Emergency** | Urgent change to restore service | Post-implementation review | Production hotfixes, security vulnerability remediation, system outages |

### 2.2 Change Risk Assessment

**Risk Factors Evaluated:**

1. **Impact:**
   - Low: Single user or non-critical system
   - Medium: Department or important but non-critical system
   - High: Enterprise-wide or business-critical system

2. **Complexity:**
   - Low: Single component, well-understood technology
   - Medium: Multiple components or moderate complexity
   - High: Complex integration or new/unfamiliar technology

3. **Testing Coverage:**
   - Low: Minimal testing or untested change
   - Medium: Unit/integration testing completed
   - High: Full regression testing with UAT sign-off

**Risk Matrix:**

| Impact | Complexity | Minimum Testing | Approval Required |
|--------|-----------|-----------------|------------------|
| Low + Low | Low | Unit testing | Team Lead |
| Low/Medium + Medium | Medium | Integration + UAT | CAB |
| High + Any | High | Full regression + UAT | CAB + CIO |

### 2.3 Change Management Roles

| Role | Responsibilities |
|------|------------------|
| **Change Requestor** | Initiate change request, provide business justification, coordinate implementation |
| **Change Owner** | Technical lead responsible for change design, testing, and implementation |
| **Change Manager** | Oversee change process, schedule CAB meetings, ensure compliance with standards |
| **Change Advisory Board (CAB)** | Review and approve/reject normal and major changes based on risk assessment |
| **Testing Team** | Execute test plans, document results, provide UAT sign-off |
| **Application Owner** | Business owner responsible for application functionality and availability |
| **CIO** | Final approval for major changes, oversight of emergency changes |

---

## 3. Change Management Process (Normal Changes)

### 3.1 Phase 1: Request and Planning

**Step 1: Change Request Submission**
- Requestor creates change request in ServiceNow Change Management module
- Required information:
  - **Business Justification:** Why change is needed (new feature, bug fix, compliance)
  - **Technical Description:** What will be changed (code, config, infrastructure)
  - **Affected Systems:** All systems/applications impacted
  - **Implementation Plan:** Step-by-step deployment procedure
  - **Rollback Plan:** How to revert if change fails
  - **Downtime Required:** Planned outage window (if any)
  - **Risk Assessment:** Impact, complexity, and mitigation strategies

**Step 2: Initial Review**
- Change Manager reviews request for completeness within **24 hours**
- Assigns to appropriate category (standard, normal, major)
- Requests additional information if needed
- Routes to CAB agenda (normal/major) or auto-approves (standard)

**Step 3: CAB Review Preparation**
- Change Owner prepares presentation materials
- Obtains preliminary approvals from affected application owners
- Coordinates with infrastructure, security, and database teams as needed

**Timeline:** Change request submitted at least **10 business days** before desired implementation date.

### 3.2 Phase 2: Approval

**CAB Meeting Schedule:**
- **Frequency:** Weekly (Tuesdays at 2:00 PM)
- **Attendees:** IT Operations Manager (chair), Application Development Manager, Infrastructure Manager, Database Administrator Lead, Information Security Manager, Business Representatives

**CAB Review Criteria:**
1. ✅ Complete and accurate change documentation
2. ✅ Adequate testing completed with documented results
3. ✅ Rollback plan tested and validated
4. ✅ Risk assessment reasonable and mitigation adequate
5. ✅ Implementation scheduled during approved change window
6. ✅ No conflicts with other scheduled changes
7. ✅ Business owner sign-off obtained

**CAB Decision Options:**
- **Approved:** Change may proceed as scheduled
- **Approved with Conditions:** Change approved pending specific requirements (e.g., additional testing)
- **Deferred:** Change postponed to future CAB meeting (more information needed)
- **Rejected:** Change not approved (inadequate planning, excessive risk)

**Approval Documentation:**
- CAB meeting minutes with attendance and decisions
- Approved change request in ServiceNow (status: "Approved")
- Email notification to change owner and stakeholders

**Major Change Additional Approval:**
- CAB recommendation forwarded to CIO
- CIO reviews and provides final approval within **2 business days**
- Board notification for changes affecting financial systems or >$500K budget impact

### 3.3 Phase 3: Testing and Validation

**Test Environment Promotion Path:**
Development → Test → QA → UAT → Production

**Testing Requirements by Change Type:**

| Change Type | Testing Required | Documentation |
|-------------|------------------|---------------|
| **Code Changes** | Unit tests (coverage >80%), Integration tests, Regression tests, UAT | Test scripts, test results, code coverage report, UAT sign-off |
| **Database Changes** | Schema validation, data integrity tests, performance testing, rollback test | DDL scripts, test data results, performance metrics, rollback validation |
| **Infrastructure Changes** | Configuration validation, connectivity tests, security scan, failover test | Configuration baseline, connectivity logs, vulnerability scan, DR test results |

**UAT Sign-off Requirements:**
- Business owner or designated representative
- Test scenarios covering critical business processes
- Sign-off form documenting acceptance (FORM-IT-UAT-001)
- Defects identified and remediated or documented as known issues

**Rollback Testing:**
- All changes must include tested rollback procedure
- Rollback test executed in UAT environment
- Rollback steps documented in implementation plan
- Recovery time objective (RTO) validated

### 3.4 Phase 4: Implementation

**Pre-Implementation Checklist:**
- ✅ CAB approval obtained and documented
- ✅ Testing completed successfully with UAT sign-off
- ✅ Implementation plan reviewed and validated
- ✅ Rollback plan tested and ready
- ✅ Communication sent to affected users (if customer-impacting)
- ✅ Backup of current production state completed
- ✅ Implementation team identified and available
- ✅ Monitoring tools configured to track change impact

**Change Windows:**

| System Tier | Change Window | Blackout Periods |
|-------------|---------------|------------------|
| **Tier 1 (Critical)** | Saturday 2:00 AM - 6:00 AM | Month-end (last 3 days), quarter-end, year-end, peak business seasons |
| **Tier 2 (Important)** | Weeknights 10:00 PM - 6:00 AM or weekends | Month-end close period |
| **Tier 3 (Standard)** | Anytime (business hours with notice) | None |

**Implementation Execution:**
1. **Pre-deployment:** System backup, notification to stakeholders
2. **Deployment:** Follow documented implementation plan step-by-step
3. **Validation:** Execute smoke tests to confirm change successful
4. **Monitoring:** Observe system for 2 hours post-deployment (critical systems)
5. **Notification:** Confirm completion and system availability

**Implementation Evidence:**
- Screenshots of deployment steps
- Log files showing successful change application
- Smoke test results
- System availability metrics (before/after)

### 3.5 Phase 5: Post-Implementation Review

**Post-Implementation Activities (within 24 hours):**
- Update change request status to "Implemented" or "Failed"
- Document actual vs. planned implementation time
- Record any issues encountered and resolutions
- Close change request with final comments

**Post-Implementation Review (PIR) - Major Changes:**
- Scheduled within **5 business days** of implementation
- Attendees: Change owner, CAB representative, application owner
- Review topics:
  - Did change meet objectives?
  - Were timelines accurate?
  - Did rollback plan adequacy?
  - Issues or lessons learned?
  - Process improvements identified?

**PIR Documentation:**
- Completed PIR form (FORM-IT-PIR-001)
- Lessons learned captured in knowledge base
- Process improvement recommendations tracked

---

## 4. Segregation of Duties (SoD)

### 4.1 SoD Requirements

**Principle:** No single individual should have the ability to develop, test, approve, and implement changes to production systems.

**Incompatible Duties:**
- ❌ Developer cannot approve their own code for production deployment
- ❌ Developer cannot deploy own code to production
- ❌ Same person cannot create and approve change request
- ❌ Database administrator cannot modify production data without change approval

**Enforced Separations:**

| Activity | Permitted Roles | Prohibited Combinations |
|----------|----------------|------------------------|
| **Code Development** | Developers, Engineers | Cannot deploy to production |
| **Change Approval** | CAB Members, Managers | Cannot implement approved change |
| **Production Deployment** | DevOps, Release Engineers | Cannot approve own changes |
| **Production Access** | Limited DBAs, SysAdmins | Cannot modify without change ticket |

### 4.2 Production Access Controls

**Production Environment Access:**
- **Developers:** No direct access (read-only for troubleshooting if approved)
- **DevOps/Release Engineers:** Write access restricted to deployment windows only
- **Database Administrators:** Emergency access with session recording and approval
- **System Administrators:** Privileged access with logging and quarterly review

**Deployment Methods:**
- Automated CI/CD pipelines (preferred) with approval gates
- Manual deployment by designated release engineers only
- All production access logged and monitored

**Access Logging:**
- All privileged actions logged (who, what, when, where)
- Logs retained for 1 year (3 years for financial systems)
- Monthly log review by IT Security

### 4.3 SoD Compensating Controls

**When SoD Cannot Be Fully Segregated (small teams):**
- ✅ Require peer review of all code changes (documented in GitLab/GitHub)
- ✅ Implement CAB approval as independent checkpoint
- ✅ Automated deployment tools with approval workflow
- ✅ Enhanced logging and monitoring with monthly review
- ✅ Quarterly independent review by Internal Audit

---

## 5. Standard Changes (Pre-Approved)

### 5.1 Standard Change Catalog

**Definition:** Low-risk, routine changes that follow documented procedures and are pre-approved by CAB.

**Standard Change Examples:**

| Change Type | Procedure | Approval |
|-------------|-----------|----------|
| **Password Resets** | Follow password reset SOP | Auto-approved via ServiceNow |
| **Monthly Security Patches** | Vendor patches applied per schedule | Pre-approved by CAB quarterly |
| **Software Installation (Approved List)** | Install from approved software catalog | Auto-approved |
| **SSL Certificate Renewal** | Follow certificate management procedure | Auto-approved |
| **Disk Space Expansion** | Storage expansion up to 20% | Team Lead approval |

**Standard Change Requirements:**
- Well-documented, repeatable procedure exists
- Risk assessment completed and approved by CAB
- Change follows documented procedure exactly (no deviations)
- Annual review of standard change catalog

**Standard Change Process:**
1. Submit change request in ServiceNow selecting "Standard Change" category
2. Select change type from catalog
3. Attach procedure reference
4. System auto-approves (or routes to designated approver)
5. Implement following standard procedure
6. Document completion in change ticket

---

## 6. Emergency Changes

### 6.1 Emergency Change Criteria

**When Emergency Process Allowed:**
- **Critical Production Outage:** System down affecting business operations
- **Security Vulnerability:** Immediate threat requiring urgent patch
- **Data Integrity Issue:** Risk of data corruption or loss
- **Regulatory Compliance:** Immediate change mandated by regulator

**Emergency Process NOT Allowed For:**
- Poor planning or missed deadlines
- Business requests for features ("urgent" to requestor but not true emergency)
- Changes that can wait for next change window

### 6.2 Emergency Change Process

**Abbreviated Approval Process:**

1. **Initiate Emergency Change**
   - Change owner contacts Change Manager (24/7 on-call)
   - Brief verbal/email description of issue and proposed fix
   - Justification for emergency designation

2. **Emergency Approval**
   - Change Manager evaluates emergency justification
   - Obtains verbal approval from:
     - Application Owner (or IT Operations Manager if unavailable)
     - CIO or designee (for financial systems or major impact)
   - Emergency approved or denied within **1 hour**

3. **Implementation**
   - Follow best-effort testing in non-production (if time permits)
   - Document rollback plan
   - Implement change to restore service
   - Monitor for stability

4. **Documentation (within 4 hours of implementation)**
   - Create formal change request in ServiceNow (retroactive)
   - Document emergency justification
   - Record verbal approvals obtained
   - Attach implementation evidence

5. **Post-Implementation Review (within 24 hours)**
   - Emergency CAB meeting (virtual/conference call)
   - Review emergency justification (was emergency process warranted?)
   - Evaluate change quality and impact
   - Identify preventive measures to avoid future emergencies
   - Document lessons learned

**Emergency Change Metrics:**
- Track number of emergency changes per month
- Goal: <5% of total changes via emergency process
- Root cause analysis if emergency changes exceed threshold

---

## 7. Change Management Metrics and KPIs

### 7.1 Key Performance Indicators

| Metric | Target | Measurement Frequency |
|--------|--------|---------------------|
| **Change Success Rate** | ≥95% | Monthly |
| **Emergency Change Rate** | ≤5% of total changes | Monthly |
| **Changes Causing Incidents** | ≤2% | Monthly |
| **CAB Approval Cycle Time** | ≤5 business days | Monthly |
| **Unauthorized Changes Detected** | 0 | Monthly |
| **Changes with Complete Documentation** | 100% | Quarterly (audit sample) |

**Definitions:**
- **Success Rate:** (Successful changes / Total changes) × 100
- **Change-Related Incident:** Production incident within 72 hours of change implementation directly attributable to the change

### 7.2 Reporting

**Monthly Change Management Dashboard:**
- Total changes by category (standard, normal, major, emergency)
- Success rate trends
- CAB approval metrics
- Top 5 applications by change volume
- Failed changes with root cause
- SoD compliance metrics

**Quarterly Reviews:**
- Present metrics to IT Steering Committee
- Trend analysis (improvement or degradation)
- Process optimization opportunities
- Standard change catalog updates

---

## 8. Compliance and Audit

### 8.1 Change Management Audit Controls

**Key Controls Tested by Internal Audit:**

**Control CHG-01:** All production changes documented in change management system
- **Testing:** Select sample of 25 production changes, verify change tickets exist
- **Evidence:** Change request records in ServiceNow

**Control CHG-02:** Changes approved before implementation
- **Testing:** Verify CAB or authorized approver approval on change records
- **Evidence:** CAB meeting minutes, approval workflows in ServiceNow

**Control CHG-03:** Testing performed and documented before production deployment
- **Testing:** Verify test results and UAT sign-offs attached to change tickets
- **Evidence:** Test scripts, results, UAT acceptance forms

**Control CHG-04:** Segregation of duties enforced (developer ≠ deployer)
- **Testing:** Compare user IDs of change requestor, approver, and implementer
- **Evidence:** Change ticket fields, deployment logs, access reports

**Control CHG-05:** Emergency changes reviewed post-implementation
- **Testing:** Verify emergency CAB review documentation for all emergency changes
- **Evidence:** Emergency PIR records, CAB meeting notes

### 8.2 Audit Evidence Requirements

**Documentation Maintained for Each Change:**
- ✅ Change request form (ServiceNow ticket)
- ✅ Risk assessment and impact analysis
- ✅ CAB approval (meeting minutes or workflow approval)
- ✅ Test plan and results
- ✅ UAT sign-off
- ✅ Implementation plan and rollback procedure
- ✅ Implementation evidence (screenshots, logs)
- ✅ Post-implementation validation
- ✅ PIR documentation (major changes and emergencies)

**Retention Period:** 7 years for SOX-scoped systems, 3 years for others

### 8.3 Annual Compliance Certification

**Change Management Process Owner Attestation:**
- Annual certification that change management controls are operating effectively
- Review of metrics and audit findings
- Identification of control deficiencies and remediation plans
- Sign-off by IT Operations Manager and CIO

**Certification Due Date:** January 31 each year (for prior calendar year)

---

## 9. Tools and Systems

### 9.1 Change Management Platform

**Primary Tool:** ServiceNow Change Management Module

**Key Features:**
- Change request workflow with approval routing
- CAB calendar and meeting management
- Risk assessment calculator
- Integration with incident and problem management
- Reporting and dashboards
- Automated notifications

### 9.2 Supporting Tools

| Tool | Purpose |
|------|---------|
| **GitLab/GitHub** | Source code version control, merge request approvals |
| **Jenkins/Azure DevOps** | CI/CD pipelines for automated deployments |
| **Ansible/Terraform** | Infrastructure as code, configuration management |
| **Jira** | Agile development tracking, sprint planning |
| **Confluence** | Documentation repository, runbooks |

---

## 10. Training and Competency

### 10.1 Training Requirements

| Role | Training Required | Frequency |
|------|------------------|-----------|
| **All IT Staff** | Change Management Process Overview | Annual |
| **Developers** | Secure SDLC, Code Review Best Practices | Annual |
| **Release Engineers** | Deployment Procedures, Rollback Techniques | Semi-annual |
| **CAB Members** | Risk Assessment, Change Evaluation | Annual |
| **Change Manager** | ITIL Change Management Certification | One-time + continuing education |

### 10.2 Knowledge Resources

**Change Management Wiki (Confluence):**
- Process flowcharts and decision trees
- Change request form user guide
- Standard change catalog with procedures
- Rollback plan templates
- CAB presentation templates

**On-Demand Support:**
- Change Manager office hours: Tuesdays/Thursdays 3-4 PM
- ServiceNow in-app help and tooltips
- IT Service Desk for process questions

---

## 11. Related Documents

- **ITGC-ACC-001:** IT Access Management Standard
- **ITGC-BCK-001:** Backup and Recovery Procedures
- **ITGC-INC-001:** Incident Management Process
- **ITGC-REL-001:** Release Management Standard
- **DEV-PROC-001:** Secure Software Development Lifecycle
- **FORM-IT-CHG-001:** Change Request Form Template
- **FORM-IT-UAT-001:** UAT Sign-off Form
- **FORM-IT-PIR-001:** Post-Implementation Review Form

---

## 12. Revision History

| Version | Date | Changes | Approved By |
|---------|------|---------|-------------|
| 1.0 | Jan 10, 2020 | Initial change management standard | CIO |
| 2.0 | Jul 15, 2021 | Added emergency change process | CIO |
| 3.0 | Mar 01, 2023 | Enhanced SoD controls, updated metrics | CIO |
| 3.5 | Mar 01, 2024 | Updated CAB membership, revised risk matrix | CIO |

---

**Document Classification:** Internal - Compliance Mandatory  
**Next Review Date:** March 1, 2025  
**Questions?** Contact Change Manager at changemanager@company.com
